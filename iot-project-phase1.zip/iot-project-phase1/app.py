#from flask import Flask, render_template, jsonify
from flask import Flask, render_template, request, jsonify


app = Flask(__name__, template_folder='views')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/toggle', methods=['POST'])
def toggle_led():
    # We should put the toggle LED code here:

    # For demonstration purposes, let's just return the new LED status
    switch_status = request.form.get('switch_status')
    new_status = 'ON' if switch_status == 'OFF' else 'OFF'
    return jsonify({'status': new_status})

if __name__ == '__main__':
    app.run(debug=True)
