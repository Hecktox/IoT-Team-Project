from flask import Flask, render_template, request, jsonify
import RPi.GPIO as GPIO

app = Flask(__name__, template_folder='views')

# Set up GPIO using BCM numbering
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Set up GPIO 17 as an output
LED_PIN = 17
GPIO.setup(LED_PIN, GPIO.OUT)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/toggle', methods=['POST'])
def toggle_led():
    switch_status = request.form.get('switch_status')

    # Toggle the LED
    if switch_status == 'OFF':
        GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on the LED
        new_status = 'ON'
    else:
        GPIO.output(LED_PIN, GPIO.LOW)   # Turn off the LED
        new_status = 'OFF'

    return jsonify({'status': new_status})

if __name__ == '__main__':
    app.run(debug=True)