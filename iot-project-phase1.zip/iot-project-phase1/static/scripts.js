document.getElementById('switchButton').addEventListener('click', function() {
    const ledIcon = document.getElementById('ledIcon');
    let switchStatus = document.getElementById('switchStatus').innerText;
    let newStatus = switchStatus === 'OFF' ? 'ON' : 'OFF';

    fetch('/toggle', {
        method: 'POST',
        body: new URLSearchParams({ switch_status: switchStatus }),
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    .then(response => response.json())
    .then(data => {
        ledIcon.src = `/static/images/led_${data.status.toLowerCase()}.png`;
        document.getElementById('switchStatus').innerText = data.status;
    });
});
